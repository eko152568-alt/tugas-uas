
import { Destination } from './types';

export const MOCK_DESTINATIONS: Destination[] = [
  {
    id: '1',
    name: 'Raja Ampat Islands',
    location: 'West Papua, Indonesia',
    description: 'A paradise for divers and nature enthusiasts with vibrant marine life.',
    price: 1200,
    rating: 4.9,
    imageUrl: 'https://picsum.photos/seed/raja/800/600',
    category: 'Nature'
  },
  {
    id: '2',
    name: 'Borobudur Temple',
    location: 'Magelang, Indonesia',
    description: 'The world\'s largest Buddhist temple, a masterpiece of ancient architecture.',
    price: 150,
    rating: 4.8,
    imageUrl: 'https://picsum.photos/seed/boro/800/600',
    category: 'Culture'
  },
  {
    id: '3',
    name: 'Uluwatu Temple',
    location: 'Bali, Indonesia',
    description: 'Stunning cliffside temple with breathtaking sunset views over the Indian Ocean.',
    price: 80,
    rating: 4.7,
    imageUrl: 'https://picsum.photos/seed/bali/800/600',
    category: 'Beach'
  },
  {
    id: '4',
    name: 'Mount Bromo',
    location: 'East Java, Indonesia',
    description: 'An active volcano and part of the Tengger massif, famous for sunrise treks.',
    price: 200,
    rating: 4.9,
    imageUrl: 'https://picsum.photos/seed/bromo/800/600',
    category: 'Nature'
  }
];
