
import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Navbar from './components/Navbar';
import Home from './views/Home';
import Login from './views/Login';
import Destinations from './views/Destinations';
import Dashboard from './views/Dashboard';

const PrivateRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? <>{children}</> : <Navigate to="/login" />;
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen flex flex-col bg-slate-50">
          <Navbar />
          <main className="flex-1">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/login" element={<Login />} />
              <Route path="/destinations" element={<Destinations />} />
              <Route 
                path="/dashboard" 
                element={
                  <PrivateRoute>
                    <Dashboard />
                  </PrivateRoute>
                } 
              />
              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </main>
          <footer className="bg-slate-900 text-white py-12">
            <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
              <div className="col-span-1 md:col-span-2">
                <div className="flex items-center gap-2 text-indigo-400 font-bold text-2xl mb-4">
                  <i className="fa-solid fa-map-location-dot"></i>
                  <span>Wanderlust</span>
                </div>
                <p className="text-slate-400 max-w-sm">Making your Indonesian travel dreams come true with smart technology and local expertise.</p>
              </div>
              <div>
                <h4 className="font-bold mb-4">Quick Links</h4>
                <ul className="space-y-2 text-slate-400 text-sm">
                  <li><a href="#" className="hover:text-white">About Us</a></li>
                  <li><a href="#" className="hover:text-white">Our Services</a></li>
                  <li><a href="#" className="hover:text-white">Terms of Policy</a></li>
                  <li><a href="#" className="hover:text-white">Privacy Policy</a></li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold mb-4">Contact Us</h4>
                <ul className="space-y-2 text-slate-400 text-sm">
                  <li className="flex items-center gap-2"><i className="fa-solid fa-envelope"></i> hello@wanderlust.id</li>
                  <li className="flex items-center gap-2"><i className="fa-solid fa-phone"></i> +62 21 555 0123</li>
                  <li className="flex items-center gap-2"><i className="fa-solid fa-location-dot"></i> Jakarta, Indonesia</li>
                </ul>
              </div>
            </div>
            <div className="max-w-7xl mx-auto px-4 mt-12 pt-8 border-t border-slate-800 text-center text-slate-500 text-xs">
              © {new Date().getFullYear()} Wanderlust Tourism Portal. Built with React & Gemini AI.
            </div>
          </footer>
        </div>
      </Router>
    </AuthProvider>
  );
};

export default App;
