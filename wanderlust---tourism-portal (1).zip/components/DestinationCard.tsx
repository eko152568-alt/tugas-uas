
import React from 'react';
import { Destination } from '../types';

interface Props {
  destination: Destination;
  onBook: (destination: Destination) => void;
}

const DestinationCard: React.FC<Props> = ({ destination, onBook }) => {
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden border border-slate-200 hover:shadow-md transition-shadow group">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={destination.imageUrl} 
          alt={destination.name} 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur px-2 py-1 rounded-lg text-xs font-bold text-indigo-600">
          ${destination.price}/pax
        </div>
      </div>
      <div className="p-5">
        <div className="flex justify-between items-start mb-2">
          <span className="text-xs font-semibold text-indigo-500 uppercase tracking-wider">{destination.category}</span>
          <div className="flex items-center text-amber-500 text-sm">
            <i className="fa-solid fa-star mr-1"></i>
            <span className="font-bold">{destination.rating}</span>
          </div>
        </div>
        <h3 className="text-lg font-bold text-slate-800 mb-1">{destination.name}</h3>
        <p className="text-sm text-slate-500 flex items-center mb-3">
          <i className="fa-solid fa-location-dot mr-1 text-indigo-400"></i>
          {destination.location}
        </p>
        <p className="text-sm text-slate-600 line-clamp-2 mb-4 leading-relaxed">
          {destination.description}
        </p>
        <button 
          onClick={() => onBook(destination)}
          className="w-full py-2 bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white rounded-lg font-semibold text-sm transition-all"
        >
          Book Now
        </button>
      </div>
    </div>
  );
};

export default DestinationCard;
