
import React, { useState, useMemo } from 'react';
import { MOCK_DESTINATIONS } from '../constants';
import DestinationCard from '../components/DestinationCard';
import { Destination } from '../types';

const Destinations: React.FC = () => {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [selectedDest, setSelectedDest] = useState<Destination | null>(null);

  const filtered = useMemo(() => {
    return MOCK_DESTINATIONS.filter(dest => {
      const matchesSearch = dest.name.toLowerCase().includes(search.toLowerCase()) || 
                            dest.location.toLowerCase().includes(search.toLowerCase());
      const matchesCat = category === 'All' || dest.category === category;
      return matchesSearch && matchesCat;
    });
  }, [search, category]);

  const handleBookClick = (dest: Destination) => {
    setSelectedDest(dest);
    setShowBookingModal(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-10">
        <h1 className="text-3xl font-bold text-slate-800 mb-2">Explore Destinations</h1>
        <p className="text-slate-500">Find your next adventure from our curated list of paradise locations.</p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <i className="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
          <input 
            type="text" 
            placeholder="Search destination, city, or country..."
            className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent bg-white shadow-sm"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 custom-scrollbar">
          {['All', 'Nature', 'Beach', 'Culture', 'City'].map(cat => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`px-6 py-3 rounded-xl font-medium transition-all whitespace-nowrap shadow-sm border ${category === cat ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-600 border-slate-200 hover:border-indigo-300'}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {filtered.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {filtered.map(dest => (
            <DestinationCard key={dest.id} destination={dest} onBook={handleBookClick} />
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-white rounded-2xl border border-dashed border-slate-300">
          <div className="w-20 h-20 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="fa-solid fa-map-pin text-3xl"></i>
          </div>
          <h3 className="text-xl font-bold text-slate-800 mb-1">No destinations found</h3>
          <p className="text-slate-500">Try adjusting your search or filters to find what you're looking for.</p>
        </div>
      )}

      {/* Booking Modal Overlay */}
      {showBookingModal && selectedDest && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" onClick={() => setShowBookingModal(false)}></div>
          <div className="relative bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="h-32 relative">
              <img src={selectedDest.imageUrl} className="w-full h-full object-cover" alt="" />
              <button 
                onClick={() => setShowBookingModal(false)}
                className="absolute top-4 right-4 bg-white/50 backdrop-blur rounded-full w-8 h-8 flex items-center justify-center hover:bg-white"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
            <div className="p-8">
              <h2 className="text-2xl font-bold text-slate-800 mb-1">Book Trip to {selectedDest.name}</h2>
              <p className="text-slate-500 mb-6">{selectedDest.location}</p>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Travel Date</label>
                  <input type="date" className="w-full px-4 py-2 border rounded-xl" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Guests</label>
                    <input type="number" min="1" defaultValue="1" className="w-full px-4 py-2 border rounded-xl" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Package</label>
                    <select className="w-full px-4 py-2 border rounded-xl bg-white">
                      <option>Basic ($150)</option>
                      <option>Premium ($250)</option>
                      <option>VIP ($400)</option>
                    </select>
                  </div>
                </div>
              </div>
              
              <div className="mt-8 flex gap-4">
                <button 
                  onClick={() => {
                    alert('Booking feature coming soon!');
                    setShowBookingModal(false);
                  }}
                  className="flex-1 bg-indigo-600 text-white py-3 rounded-xl font-bold shadow-lg hover:shadow-indigo-200 transition-all"
                >
                  Confirm Reservation
                </button>
                <button 
                  onClick={() => setShowBookingModal(false)}
                  className="px-6 py-3 border border-slate-200 text-slate-600 rounded-xl font-bold hover:bg-slate-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Destinations;
