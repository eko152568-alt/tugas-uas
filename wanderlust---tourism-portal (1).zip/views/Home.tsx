
import React, { useState } from 'react';
import { MOCK_DESTINATIONS } from '../constants';
import DestinationCard from '../components/DestinationCard';
import { getTravelAssistantResponse } from '../services/geminiService';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

const Home: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [aiInput, setAiInput] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleAskAi = async () => {
    if (!aiInput.trim()) return;
    setIsLoading(true);
    const response = await getTravelAssistantResponse(`Tell me about travel opportunities in Indonesia for someone interested in: ${aiInput}`);
    setAiResponse(response || '');
    setIsLoading(false);
  };

  const handleBook = () => {
    if (!isAuthenticated) {
      navigate('/login');
    } else {
      navigate('/destinations');
    }
  };

  return (
    <div className="flex flex-col gap-12 pb-20">
      {/* Hero Section */}
      <section className="relative h-[500px] flex items-center justify-center text-white text-center px-4 overflow-hidden rounded-b-[40px] md:rounded-b-[80px]">
        <img 
          src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80&w=2000" 
          className="absolute inset-0 w-full h-full object-cover brightness-50"
          alt="Paradise beach"
        />
        <div className="relative z-10 max-w-3xl">
          <h1 className="text-4xl md:text-6xl font-extrabold mb-6 leading-tight">Explore the Magic of Indonesia</h1>
          <p className="text-lg md:text-xl mb-8 opacity-90">Discover hidden gems, cultural wonders, and pristine nature across the archipelago.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={() => navigate('/destinations')}
              className="bg-indigo-600 hover:bg-indigo-700 px-8 py-3 rounded-xl font-bold transition-all shadow-lg"
            >
              Start Exploring
            </button>
            <button className="bg-white/20 backdrop-blur hover:bg-white/30 px-8 py-3 rounded-xl font-bold transition-all border border-white/30">
              View Packages
            </button>
          </div>
        </div>
      </section>

      {/* AI Assistant Section */}
      <section className="max-w-5xl mx-auto px-4 w-full">
        <div className="bg-gradient-to-br from-indigo-600 to-blue-700 rounded-3xl p-8 md:p-12 text-white shadow-xl relative overflow-hidden">
          <div className="relative z-10 flex flex-col md:flex-row gap-8 items-center">
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold mb-4">Smart Travel Assistant</h2>
              <p className="opacity-80 mb-6 italic">Powered by Gemini AI</p>
              <p className="mb-8">Looking for the perfect itinerary? Describe what you like, and our AI will plan it for you instantly.</p>
              <div className="flex gap-2">
                <input 
                  type="text"
                  placeholder="e.g. I love snorkeling and ancient temples..."
                  className="flex-1 px-4 py-3 rounded-xl bg-white/10 border border-white/20 focus:outline-none focus:bg-white/20 placeholder:text-white/50"
                  value={aiInput}
                  onChange={(e) => setAiInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAskAi()}
                />
                <button 
                  onClick={handleAskAi}
                  disabled={isLoading}
                  className="bg-white text-indigo-600 px-6 py-3 rounded-xl font-bold hover:bg-indigo-50 transition-colors disabled:opacity-50"
                >
                  {isLoading ? <i className="fa-solid fa-spinner animate-spin"></i> : <i className="fa-solid fa-paper-plane"></i>}
                </button>
              </div>
            </div>
            <div className="md:w-1/2 w-full h-64 bg-white/10 rounded-2xl p-4 overflow-y-auto border border-white/20 backdrop-blur-sm custom-scrollbar">
              {aiResponse ? (
                <div className="prose prose-invert prose-sm max-w-none">
                  {aiResponse.split('\n').map((line, i) => <p key={i} className="mb-2">{line}</p>)}
                </div>
              ) : (
                <div className="h-full flex items-center justify-center text-white/40 text-sm italic">
                  Recommendations will appear here...
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Featured Destinations */}
      <section className="max-w-7xl mx-auto px-4 w-full">
        <div className="flex justify-between items-end mb-8">
          <div>
            <h2 className="text-3xl font-bold text-slate-800">Popular Destinations</h2>
            <p className="text-slate-500 mt-1">Handpicked spots just for you</p>
          </div>
          <button 
            onClick={() => navigate('/destinations')}
            className="text-indigo-600 font-semibold flex items-center gap-1 hover:gap-2 transition-all"
          >
            See All <i className="fa-solid fa-arrow-right text-xs"></i>
          </button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {MOCK_DESTINATIONS.map(dest => (
            <DestinationCard key={dest.id} destination={dest} onBook={handleBook} />
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="bg-indigo-50 py-16">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold text-slate-800 mb-10">Browse by Category</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {['Nature', 'Culture', 'Beach', 'City'].map(cat => (
              <div key={cat} className="bg-white p-6 rounded-2xl border border-slate-200 hover:border-indigo-300 hover:shadow-md transition-all cursor-pointer group">
                <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                  <i className={`fa-solid ${cat === 'Nature' ? 'fa-leaf' : cat === 'Culture' ? 'fa-landmark' : cat === 'Beach' ? 'fa-umbrella-beach' : 'fa-city'} text-xl`}></i>
                </div>
                <span className="font-bold text-slate-700">{cat}</span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
