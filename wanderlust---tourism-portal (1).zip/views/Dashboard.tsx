
import React from 'react';
import { useAuth } from '../context/AuthContext';
import { MOCK_DESTINATIONS } from '../constants';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const isAdmin = user?.role === 'ADMIN';

  // Mock statistics
  const stats = isAdmin ? [
    { label: 'Total Revenue', value: '$45,200', icon: 'fa-dollar-sign', color: 'bg-emerald-500' },
    { label: 'Total Bookings', value: '1,280', icon: 'fa-calendar-check', color: 'bg-indigo-500' },
    { label: 'Active Visitors', value: '450', icon: 'fa-users', color: 'bg-blue-500' },
    { label: 'Destinations', value: '24', icon: 'fa-map', color: 'bg-amber-500' },
  ] : [
    { label: 'Your Trips', value: '3', icon: 'fa-suitcase-rolling', color: 'bg-indigo-500' },
    { label: 'Points Earned', value: '1,250', icon: 'fa-star', color: 'bg-amber-500' },
    { label: 'Wishlist', value: '12', icon: 'fa-heart', color: 'bg-rose-500' },
    { label: 'Messages', value: '2', icon: 'fa-envelope', color: 'bg-sky-500' },
  ];

  const recentActivities = [
    { id: 1, action: 'Booking Confirmed', item: 'Borobudur Temple', time: '2 hours ago', status: 'success' },
    { id: 2, action: 'Payment Received', item: 'Mount Bromo Package', time: '5 hours ago', status: 'success' },
    { id: 3, action: 'New Inquiry', item: 'Raja Ampat Luxury Dive', time: '1 day ago', status: 'warning' },
    { id: 4, action: 'Review Posted', item: 'Uluwatu Sunset Tour', time: '2 days ago', status: 'info' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-10">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Hello, {user?.name}!</h1>
          <p className="text-slate-500">Welcome to your {isAdmin ? 'Administration' : 'Member'} Dashboard</p>
        </div>
        <div className="flex gap-2">
          {isAdmin ? (
            <button className="bg-indigo-600 text-white px-6 py-2 rounded-xl font-semibold shadow-lg hover:shadow-indigo-200 flex items-center gap-2">
              <i className="fa-solid fa-plus"></i> Add Destination
            </button>
          ) : (
            <button className="bg-indigo-600 text-white px-6 py-2 rounded-xl font-semibold shadow-lg hover:shadow-indigo-200 flex items-center gap-2">
              <i className="fa-solid fa-search"></i> Find Trips
            </button>
          )}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        {stats.map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-5">
            <div className={`w-14 h-14 ${stat.color} text-white rounded-2xl flex items-center justify-center text-xl shadow-lg shadow-${stat.color.split('-')[1]}-200`}>
              <i className={`fa-solid ${stat.icon}`}></i>
            </div>
            <div>
              <p className="text-sm font-medium text-slate-500 uppercase tracking-wider">{stat.label}</p>
              <p className="text-2xl font-bold text-slate-800">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Section */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
            <div className="p-6 border-b border-slate-50 flex justify-between items-center">
              <h3 className="text-lg font-bold text-slate-800">{isAdmin ? 'All Active Bookings' : 'Your Recent Bookings'}</h3>
              <button className="text-indigo-600 text-sm font-semibold hover:underline">View All</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
                  <tr>
                    <th className="px-6 py-4 font-semibold">Destination</th>
                    <th className="px-6 py-4 font-semibold">Date</th>
                    <th className="px-6 py-4 font-semibold">Amount</th>
                    <th className="px-6 py-4 font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {MOCK_DESTINATIONS.slice(0, 4).map((dest) => (
                    <tr key={dest.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <img src={dest.imageUrl} className="w-10 h-10 rounded-lg object-cover" alt="" />
                          <div className="font-semibold text-slate-800">{dest.name}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">Oct 12, 2023</td>
                      <td className="px-6 py-4 text-sm font-bold text-slate-800">${dest.price * 2}</td>
                      <td className="px-6 py-4">
                        <span className="bg-emerald-100 text-emerald-600 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide">Confirmed</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Sidebar Section */}
        <div className="space-y-8">
          <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
            <h3 className="text-lg font-bold text-slate-800 mb-6">Recent Activity</h3>
            <div className="space-y-6">
              {recentActivities.map((activity) => (
                <div key={activity.id} className="flex gap-4">
                  <div className="relative">
                    <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-500 text-sm">
                      <i className={`fa-solid ${activity.status === 'success' ? 'fa-check text-emerald-500' : 'fa-bell text-amber-500'}`}></i>
                    </div>
                    {activity.id < recentActivities.length && (
                      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[1px] h-6 bg-slate-200"></div>
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-800">{activity.action}</p>
                    <p className="text-xs text-slate-500 mb-1">{activity.item}</p>
                    <p className="text-[10px] text-slate-400 font-medium">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {!isAdmin && (
            <div className="bg-indigo-600 rounded-2xl p-6 text-white shadow-xl shadow-indigo-100">
              <h3 className="font-bold text-lg mb-2">Need Travel Advice?</h3>
              <p className="text-sm text-indigo-100 mb-6">Talk to our smart assistant powered by Gemini for your next itinerary.</p>
              <button 
                onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                className="w-full py-3 bg-white text-indigo-600 rounded-xl font-bold shadow-lg hover:bg-indigo-50 transition-all"
              >
                Go to Assistant
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
