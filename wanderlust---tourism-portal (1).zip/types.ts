
export type Role = 'ADMIN' | 'USER';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
}

export interface Destination {
  id: string;
  name: string;
  location: string;
  description: string;
  price: number;
  rating: number;
  imageUrl: string;
  category: 'Nature' | 'City' | 'Culture' | 'Beach';
}

export interface Booking {
  id: string;
  userId: string;
  destinationId: string;
  destinationName: string;
  date: string;
  status: 'PENDING' | 'CONFIRMED' | 'CANCELLED';
  guests: number;
  totalPrice: number;
}
